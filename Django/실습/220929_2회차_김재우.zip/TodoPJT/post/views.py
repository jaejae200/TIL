from django.shortcuts import render, redirect
from .models import Post

# Create your views here.


def index(request):
    return render(request, "post/index.html")


def posts(request):
    return render(request, "post/posts.html")


def create(request):
    title = request.GET.get("title")
    content = request.GET.get("content")

    Post.objects.create(title=title, content=content)

    return redirect("post:index")
