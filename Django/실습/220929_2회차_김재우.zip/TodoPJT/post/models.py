from django.db import models

# Create your models here.


class Post(models.Model):
    title = models.TextField(max_length=80)
    content = models.TextField()
    # user 회원가입 구현은 아직 모르겠습니다.
