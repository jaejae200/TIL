from django.urls import path
from . import views

app_name = "post"
urlpatterns = [
    path("", views.index, name="index"),
    path("posts/", views.posts, name="posts"),
    path("create/", views.create, name="create"),
]
