from django.shortcuts import render
import random

# Create your views here.


def index(request):

    return render(request, "index.html")


def result(request):
    name = request.GET.get("user-name")

    animal = [
        "고양이",
        "강아지",
        "거북이",
        "토끼",
        "뱀",
        "사자",
        "호랑이",
        "표범",
        "치타",
        "하이에나",
        "기린",
        "코끼리",
        "코뿔소",
        "하마",
        "악어",
        "펭귄",
        "부엉이",
        "올빼미",
        "곰",
        "돼지",
        "소",
        "닭",
        "독수리",
        "타조",
        "고릴라",
        "오랑우탄",
        "침팬지",
        "원숭이",
        "코알라",
        "캥거루",
        "고래",
        "상어",
        "칠면조",
        "직박구리",
        "쥐",
        "청설모",
        "메추라기",
        "앵무새",
        "삵",
        "스라소니",
        "판다",
        "오소리",
        "오리",
        "거위",
        "백조",
        "두루미",
        "고슴도치",
        "두더지",
        "우파루파",
        "맹꽁이",
        "너구리",
        "개구리",
        "두꺼비",
        "카멜레온",
        "이구아나",
        "노루",
        "제비",
        "까치",
        "고라니",
        "수달",
        "당나귀",
        "순록",
        "염소",
        "공작",
        "바다표범",
        "들소",
        "박쥐",
        "참새",
        "물개",
        "바다사자",
        "살모사",
        "구렁이",
        "얼룩말",
        "산양",
        "멧돼지",
        "카피바라",
        "도롱뇽",
        "북극곰",
        "퓨마",
        "미어캣",
        "코요테",
        "라마",
        "딱따구리",
        "기러기",
        "비둘기",
        "스컹크",
        "돌고래",
        "까마귀",
        "매",
        "낙타",
        "여우",
        "사슴",
        "늑대",
        "재규어",
        "알파카",
        "양",
        "다람쥐",
        "담비",
    ]
    animal_result = random.sample(animal, 1)

    context = {"name": name, "animal": animal_result}
    return render(request, "result.html", context)


def is_odd_even(request, _number):
    if _number == 0:
        result = "0"
    elif _number % 2 == 0:
        result = "짝수"
    else:
        result = "홀수"

    context = {"number": _number, "result": result}

    return render(request, "is-odd-even.html", context)


def klolem(request):
    return render(request, "klolem.html")


def text(request):
    paragraph = request.GET.get("paragraph")
    word = request.GET.get("word")
    paragraph = int(paragraph)
    word = int(word)

    word_list = [
        "고양이",
        "강아지",
        "거북이",
        "토끼",
        "뱀",
        "사자",
        "호랑이",
        "표범",
        "치타",
        "하이에나",
        "기린",
        "코끼리",
        "코뿔소",
        "하마",
        "악어",
        "펭귄",
        "부엉이",
        "올빼미",
        "곰",
        "돼지",
        "소",
        "닭",
        "독수리",
        "타조",
        "고릴라",
        "오랑우탄",
        "침팬지",
        "원숭이",
        "코알라",
        "캥거루",
        "고래",
        "상어",
        "칠면조",
        "직박구리",
        "쥐",
        "청설모",
        "메추라기",
        "앵무새",
        "삵",
        "스라소니",
        "판다",
        "오소리",
        "오리",
        "거위",
        "백조",
        "두루미",
        "고슴도치",
        "두더지",
        "우파루파",
        "맹꽁이",
        "너구리",
        "개구리",
        "두꺼비",
        "카멜레온",
        "이구아나",
        "노루",
        "제비",
        "까치",
        "고라니",
        "수달",
        "당나귀",
        "순록",
        "염소",
        "공작",
        "바다표범",
        "들소",
        "박쥐",
        "참새",
        "물개",
        "바다사자",
        "살모사",
        "구렁이",
        "얼룩말",
        "산양",
        "멧돼지",
        "카피바라",
        "도롱뇽",
        "북극곰",
        "퓨마",
        "미어캣",
        "코요테",
        "라마",
        "딱따구리",
        "기러기",
        "비둘기",
        "스컹크",
        "돌고래",
        "까마귀",
        "매",
        "낙타",
        "여우",
        "사슴",
        "늑대",
        "재규어",
        "알파카",
        "양",
        "다람쥐",
        "담비",
    ]

    words = []
    result_word = []
    for _ in range(paragraph + 1):
        words.append(result_word)
        result_word = []
        for _ in range(word):
            result_word.append(random.choice(word_list))

    del words[0]

    context = {"words": words}

    return render(request, "text.html", context)


def calculate(request, number1, number2):

    result1 = number1 + number2
    result2 = number1 - number2
    result3 = number1 * number2
    result4 = number1 // number2

    context = {
        "number1": number1,
        "number2": number2,
        "result1": result1,
        "result2": result2,
        "result3": result3,
        "result4": result4,
    }

    return render(request, "calculate.html", context)
